GitHub Actions ile Tek Tık APK
===============================
1) Bu klasörü bir GitHub reposuna yükleyin (Upload files).
2) Repo 'Actions' sekmesinde 'Build Android APK' workflow'u otomatik görünür.
3) 'Run workflow' deyin veya push yapın.
4) Bittiğinde 'Artifacts' bölümünde 'app-debug.apk' indirilebilir.
5) Daha önce verdiğim OMR proje dosyalarını bu projenin 'app' klasörüne kopyalarsanız gerçek uygulamanız derlenir.
